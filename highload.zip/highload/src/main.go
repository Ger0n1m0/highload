package main

import (
	"highload/goncharov/api"
	"highload/goncharov/config"
	"highload/goncharov/db"
	"log"
	"net/http"
	"os"

	_ "github.com/jackc/pgx/stdlib"
)

func main() {

	envPath := ".env"
	if len(os.Args) > 1 {
		envPath = os.Args[1]
	}
	log.Println("Read configuration file: " + envPath)
	_, err := config.Read(envPath)
	if err != nil {
		log.Fatal("Can't read config: " + envPath)
	}

	addr := config.MakeServerAddr()

	// Check DB connection
	db.Connect()

	// create a type that satisfies the `api.ServerInterface`, which contains an implementation of every operation from the generated code
	server := api.NewServer()

	r := http.NewServeMux()

	r.Handle("GET /", http.FileServer(http.Dir("./static")))

	// get an `http.Handler` that we can use
	h := api.HandlerFromMux(server, r)

	s := &http.Server{
		Handler: h,
		Addr:    addr,
	}

	log.Println("Server running at http://" + addr)

	// And we serve HTTP until the world ends.
	log.Fatal(s.ListenAndServe())

}
