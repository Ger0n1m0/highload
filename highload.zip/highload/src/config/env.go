package config

import (
	"fmt"
	"log"
	"os"
	"strconv"

	"github.com/joho/godotenv"
)

type appConfig struct {
	Db     dbConfig
	Server serverConfig
}

type dbConfig struct {
	Host     string
	Port     string
	User     string
	Password string
	Database string
}

type serverConfig struct {
	Interface string
	Port      string
}

var App appConfig

func MakeServerAddr() string {
	return fmt.Sprintf("%s:%s", App.Server.Interface, App.Server.Port)
}

func MakeDbConnectionRow(showPassword bool) string {
	pass := App.Db.Password
	if showPassword == false {
		pass = "******"
	}

	return fmt.Sprintf("postgres://%s:%s@%s:%s/%s", App.Db.User, pass, App.Db.Host, App.Db.Port, App.Db.Database)
}

func Read(filePath string) (appConfig, error) {
	err := godotenv.Load(filePath)
	if err != nil {
		log.Fatal("Error loading .env file: " + filePath)
	}

	_, err = strconv.Atoi(os.Getenv("PG_PORT"))
	if err != nil {
		log.Fatal("PG_PORT must be integer")
	}

	_, err = strconv.Atoi(os.Getenv("SERVER_PORT"))
	if err != nil {
		log.Fatal("SERVER_PORT must be integer")
	}

	App = appConfig{
		Db: dbConfig{
			Host:     os.Getenv("PG_HOST"),     //localhost
			Port:     os.Getenv("PG_PORT"),     //9432
			User:     os.Getenv("PG_USER"),     //localhost
			Password: os.Getenv("PG_PASSWORD"), //localhost
			Database: os.Getenv("PG_DATABASE"), //localhost
		},
		Server: serverConfig{
			Interface: os.Getenv("SERVER_INTERFACE"), //localhost ,
			Port:      os.Getenv("SERVER_PORT"),      //localhost ,
		},
	}
	return App, err
}
