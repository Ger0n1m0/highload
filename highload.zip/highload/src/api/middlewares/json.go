package middlewares

import (
	"net/http"

	"github.com/google/uuid"
)

type Middleware func(next http.Handler) http.Handler

func Chain(middleware ...Middleware) http.Handler {
	var handler http.Handler
	for i := range middleware {
		handler = middleware[len(middleware)-1-i](handler)
	}

	return handler
}

// ResponseHeader is a middleware handler that adds a header to the response
type ResponseHeader struct {
	handler http.Handler
}

// NewResponseHeader constructs a new ResponseHeader middleware handler
func JsonRequest(handlerToWrap http.Handler) *ResponseHeader {
	return &ResponseHeader{handlerToWrap}
}

// ServeHTTP handles the request by adding the response header
func (rh *ResponseHeader) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	requestId := r.Header.Get("X-Request-Id")
	if requestId == "" {
		requestId = uuid.NewString()
	}
	w.Header().Set("Accept", "application/json")
	w.Header().Set("X-Request-Id", requestId)
	w.Header().Set("Content-Type", "application/json")

	//call the wrapped handler
	rh.handler.ServeHTTP(w, r)
}
