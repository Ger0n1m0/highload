package api

import (
	"encoding/json"
	"highload/goncharov/api/actions"

	"net/http"
)

// ensure that we've conformed to the `ServerInterface` with a compile-time check
var _ ServerInterface = (*Server)(nil)

type Server struct{}

// GetDialogUserIdList implements ServerInterface.
func (s Server) GetDialogUserIdList(w http.ResponseWriter, r *http.Request, userId string) {
	panic("unimplemented")
}

// GetPostFeed implements ServerInterface.
func (s Server) GetPostFeed(w http.ResponseWriter, r *http.Request, params GetPostFeedParams) {
	panic("unimplemented")
}

// GetPostGetId implements ServerInterface.
func (s Server) GetPostGetId(w http.ResponseWriter, r *http.Request, id string) {
	panic("unimplemented")
}

// GetUserGetId implements ServerInterface.
func (s Server) GetUserGetId(w http.ResponseWriter, r *http.Request, id string) {
	actions.GetUserGetIdAction(w, r, id)
}

// GetUserSearch implements ServerInterface.
func (s Server) GetUserSearch(w http.ResponseWriter, r *http.Request, params GetUserSearchParams) {
	panic("unimplemented")
}

// PostDialogUserIdSend implements ServerInterface.
func (s Server) PostDialogUserIdSend(w http.ResponseWriter, r *http.Request, userId string) {
	panic("unimplemented")
}

// PostLogin implements ServerInterface.
func (s Server) PostLogin(w http.ResponseWriter, r *http.Request) {
	actions.PostLoginAction(w, r)
}

// PostPostCreate implements ServerInterface.
func (s Server) PostPostCreate(w http.ResponseWriter, r *http.Request) {
	panic("unimplemented")
}

// PostUserRegister implements ServerInterface.
func (s Server) PostUserRegister(w http.ResponseWriter, r *http.Request) {
	actions.PostUserRegisterAction(w, r)
}

// PutFriendDeleteUserId implements ServerInterface.
func (s Server) PutFriendDeleteUserId(w http.ResponseWriter, r *http.Request, userId string) {
	panic("unimplemented")
}

// PutFriendSetUserId implements ServerInterface.
func (s Server) PutFriendSetUserId(w http.ResponseWriter, r *http.Request, userId string) {
	panic("unimplemented")
}

// PutPostDeleteId implements ServerInterface.
func (s Server) PutPostDeleteId(w http.ResponseWriter, r *http.Request, id string) {
	panic("unimplemented")
}

// PutPostUpdate implements ServerInterface.
func (s Server) PutPostUpdate(w http.ResponseWriter, r *http.Request) {
	panic("unimplemented")
}

func NewServer() Server {
	return Server{}
}

// Pong defines model for Pong.
type Pong struct {
	Ping string `json:"ping"`
}

// (GET /ping)
func (Server) GetPing(w http.ResponseWriter, r *http.Request) {
	resp := Pong{
		Ping: "pong",
	}

	w.WriteHeader(http.StatusOK)
	_ = json.NewEncoder(w).Encode(resp)
}
