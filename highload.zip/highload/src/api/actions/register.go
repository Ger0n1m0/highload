package actions

import (
	"encoding/json"
	"fmt"
	"highload/goncharov/db"
	"io"
	"net/http"
	"time"

	"github.com/google/uuid"
	"golang.org/x/crypto/bcrypt"
)

type PostUserRegisterReq struct {
	Login      string  `json:"login"`
	FirstName  string  `json:"first_name"`
	SecondName string  `json:"second_name"`
	Birthdate  string  `json:"birthdate"`
	Biography  *string `json:"biography"`
	City       string  `json:"city"`
	Sex        string  `json:"sex"`
	Password   string  `json:"password"`
}

type PostUserRegisterResp struct {
	Id string `json:"user_id"`
}

// Register new user, create hash request
// POST /user/register
func PostUserRegisterAction(w http.ResponseWriter, r *http.Request) {
	var err error
	HandleJson(w, r)

	var bodyBytes []byte
	bodyBytes, _ = io.ReadAll(r.Body)
	reqData := PostUserRegisterReq{}
	json.Unmarshal(bodyBytes, &reqData)

	con := db.Connect()
	userId := uuid.New().String()

	// Searching for city in DB
	city := db.City{}
	err = con.Get(&city, db.QueryGetCity, reqData.City)
	if err != nil {
		HandleError400(w, err, fmt.Sprintf(ErrorCodes[2000], reqData.City), 2000)
		return
	}

	birthDay, err := time.Parse("02.01.2006", reqData.Birthdate)
	if err != nil {
		HandleError400(w, err, fmt.Sprintf(ErrorCodes[2001], reqData.Birthdate), 2001)
		return
	}

	// Hashing password before insert
	hash, err := bcrypt.GenerateFromPassword([]byte(reqData.Password), 10)
	if err != nil {
		// mismatch
		HandleError500(w, err, ErrorCodes[3000], 3000)
		return
	}
	reqData.Password = string(hash)

	tx := con.MustBegin()
	_, err = tx.NamedExec(db.QueryInsertUser, map[string]interface{}{
		"id":          userId,
		"first_name":  reqData.FirstName,
		"second_name": reqData.SecondName,
		"birth_date":  birthDay,
		"create_date": time.Now().Local().Format(time.RFC3339),
		"update_date": time.Now().Local().Format(time.RFC3339),
		"city":        city.Id,
		"description": reqData.Biography,
		"sex":         reqData.Sex,
		"is_active":   true,
	})
	if err != nil {
		HandleError500(w, err, fmt.Sprintf(ErrorCodes[1001], err.Error()), 1001)
	}

	_, err = tx.NamedExec(db.QueryInsertLoginData, map[string]interface{}{
		"id":          uuid.New().String(),
		"login":       reqData.Login,
		"password":    reqData.Password,
		"user":        userId,
		"create_date": time.Now().Local().Format(time.RFC3339),
		"update_date": time.Now().Local().Format(time.RFC3339),
		"is_active":   true,
	})

	if err != nil {
		HandleError500(w, err, fmt.Sprintf(ErrorCodes[1001], err.Error()), 1001)
	}
	err = tx.Commit()
	if err != nil {
		// mismatch
		HandleError500(w, err, fmt.Sprintf(ErrorCodes[1001], err.Error()), 1001)
		return
	}

	// Format response
	respData := PostUserRegisterResp{
		Id: userId,
	}
	w.WriteHeader(http.StatusOK)
	_ = json.NewEncoder(w).Encode(respData)
}
