package actions

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"

	"github.com/google/uuid"
)

// Error answer structure for innert API erver errors
type httpError struct {
	Message   string `json:"message"`
	RequestId string `json:"request_id"`
	Code      int    `json:"code"`
}

func handleError(w http.ResponseWriter, err error, message string, code int, httpCode int, showDetails bool) {
	reqId := w.Header().Get("X-Request-Id")
	if reqId == "" {
		reqId = uuid.NewString()
		w.Header().Set("X-Request-Id", reqId)
	}
	log.Println(fmt.Sprintf("[%s] %s", reqId, err.Error()))
	txt := message
	if !showDetails {
		txt = "Internal server error"
	}
	answer := httpError{
		Message:   txt,
		RequestId: reqId,
		Code:      code,
	}

	w.WriteHeader(httpCode)
	_ = json.NewEncoder(w).Encode(answer)

}

// Server-side errors - don't say details to client
func HandleError500(w http.ResponseWriter, err error, message string, code int) {
	handleError(w, err, message, code, http.StatusInternalServerError, false)
}

// Client-side errors
func HandleError400(w http.ResponseWriter, err error, message string, code int) {
	handleError(w, err, message, code, http.StatusBadRequest, true)
}

// Not found errors
func HandleError404(w http.ResponseWriter, err error, message string, code int) {
	handleError(w, err, message, code, http.StatusNotFound, true)
}

// Forbidden
func HandleError403(w http.ResponseWriter, err error, message string, code int) {
	handleError(w, err, message, code, http.StatusForbidden, true)
}

// Not authorized
func HandleError401(w http.ResponseWriter, err error, message string, code int) {
	handleError(w, err, message, code, http.StatusUnauthorized, true)
}
