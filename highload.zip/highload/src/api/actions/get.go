package actions

import (
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"highload/goncharov/db"
	"net/http"
	"time"
)

type GetUserGetIdResp struct {
	Id         string  `json:"id"`
	FirstName  string  `json:"first_name"`
	SecondName string  `json:"second_name"`
	Birthdate  string  `json:"birthdate"`
	Biography  *string `json:"biography"`
	City       string  `json:"city"`
	Sex        string  `json:"sex"`
}

// POST /login
func GetUserGetIdAction(w http.ResponseWriter, r *http.Request, id string) {
	HandleJson(w, r)
	isValid := ValidateToken(w, r)
	if !isValid {
		return
	}

	con := db.Connect()
	user := db.User{}
	err := con.Get(&user, db.QueryGetUser, id)

	if err != nil && errors.Is(err, sql.ErrNoRows) {
		HandleError404(w, err, ErrorCodes[2003], 2003)
		return
	}
	if err != nil {
		HandleError500(w, err, fmt.Sprintf(ErrorCodes[1002], err.Error()), 1002)
		return
	}

	// Prepare user info response
	resp := GetUserGetIdResp{
		Id:         user.Id.String(),
		FirstName:  user.FirstName,
		SecondName: user.SecondName,
		Birthdate:  user.BirthDate.Format(time.RFC3339),
		Biography:  user.Description,
		City:       user.CityName,
		Sex:        user.Sex,
	}

	w.WriteHeader(http.StatusOK)
	_ = json.NewEncoder(w).Encode(resp)

}
