package actions

import (
	"database/sql"
	"encoding/json"
	"errors"
	"highload/goncharov/db"
	"io"
	"net/http"

	"golang.org/x/crypto/bcrypt"
)

type PostLoginReq struct {
	Login    string `json:"login"`
	Password string `json:"password"`
}

type PostLoginResp struct {
	Token string `json:"token"`
}

// POST /login
func PostLoginAction(w http.ResponseWriter, r *http.Request) {
	var err error
	HandleJson(w, r)

	var bodyBytes []byte
	bodyBytes, _ = io.ReadAll(r.Body)
	reqData := PostLoginReq{}
	json.Unmarshal(bodyBytes, &reqData)

	con := db.Connect()
	loginData := db.LoginData{}
	err = con.Get(&loginData, db.QueryGetLogin, reqData.Login)

	if err != nil && errors.Is(err, sql.ErrNoRows) {
		HandleError400(w, err, ErrorCodes[2002], 2002)
		return
	}
	if err != nil {
		HandleError400(w, err, ErrorCodes[2002], 2002)
		return
	}

	// user found check password
	err = bcrypt.CompareHashAndPassword([]byte(loginData.PasswordHash), []byte(reqData.Password))
	if err != nil {
		HandleError400(w, err, ErrorCodes[2002], 2002)
		return
	}
	// Invalidate old tokens
	err = db.IvalidateTokens()
	if err != nil {
		HandleError500(w, err, ErrorCodes[3002], 3002)
		return
	}

	// Create token SHA256
	token, errToken := db.MakeToken(&loginData)
	if errToken != nil {
		HandleError500(w, errToken, ErrorCodes[3001], 3001)
		return
	}

	// Prepare correct answer
	respData := PostLoginResp{
		Token: token.AccessToken,
	}

	w.WriteHeader(http.StatusOK)
	_ = json.NewEncoder(w).Encode(respData)
}
