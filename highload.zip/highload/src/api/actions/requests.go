package actions

import (
	"errors"
	"highload/goncharov/db"
	"net/http"
	"regexp"

	"github.com/google/uuid"
)

func HandleJson(w http.ResponseWriter, r *http.Request) {
	requestId := r.Header.Get("X-Request-Id")
	if requestId == "" {
		requestId = uuid.NewString()
	}
	w.Header().Set("Accept", "application/json")
	w.Header().Set("X-Request-Id", requestId)
	w.Header().Set("Content-Type", "application/json")
}

func ValidateToken(w http.ResponseWriter, r *http.Request) bool {
	tokenHeader := r.Header.Get("Authorization")
	if tokenHeader == "" {
		HandleError401(w, errors.New("No authorization header found"), ErrorCodes[2005], 2005)
		return false
	}
	re := regexp.MustCompile(`(?i)bearer (.+)`)
	parts := re.FindStringSubmatch(tokenHeader)

	if len(parts) != 2 {
		HandleError403(w, errors.New("Authorization header is not like Bearer xxxxx"), ErrorCodes[2004], 2004)
		return false
	}
	tokenString := parts[1]
	token := db.Token{}

	err := db.Connect().Get(&token, db.QueryGetToken, tokenString)
	if err != nil {
		HandleError403(w, errors.New("No active token found: "+err.Error()), ErrorCodes[2004], 2004)
		return false
	}

	// Invalidate old tokens
	err = db.IvalidateTokens()
	if err != nil {
		HandleError500(w, err, ErrorCodes[3002], 3002)
		return false
	}

	return true
}
