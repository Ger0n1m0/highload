package db

import (
	"time"

	"github.com/google/uuid"
)

type LoginData struct {
	Id           uuid.UUID `db:"id"`
	Login        string    `db:"login"`
	PasswordHash string    `db:"password"`
	UserId       uuid.UUID `db:"user"`
	CreateDate   time.Time `db:"create_date"`
	UpdateDate   time.Time `db:"update_date"`
	IsActive     bool      `db:"is_active"`
}

type Token struct {
	Id          uuid.UUID `db:"id"`
	UserId      uuid.UUID `db:"user"`
	AccessToken string    `db:"access_token"`
	CreateDate  time.Time `db:"create_date"`
	UpdateDate  time.Time `db:"update_date"`
	ValidUntil  time.Time `db:"valid_until"`
	IsValid     bool      `db:"is_valid"`
}

type User struct {
	Id           uuid.UUID `db:"id"`
	FirstName    string    `db:"first_name"`
	SecondName   string    `db:"second_name"`
	BirthDate    time.Time `db:"birth_date"`
	CreateDate   time.Time `db:"create_date"`
	UpdateDate   time.Time `db:"update_date"`
	CityId       uuid.UUID `db:"city"`
	CityName     string    `db:"city_name"`
	Description  *string   `db:"description"`
	Sex          string    `db:"sex"`
	IsUserActive bool      `db:"is_active"`
}

type City struct {
	Id         uuid.UUID `db:"id"`
	Name       string    `db:"name"`
	CreateDate time.Time `db:"create_date"`
	UpdateDate time.Time `db:"update_date"`
}
