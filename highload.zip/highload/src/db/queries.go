package db

var QueryGetUser string = "SELECT users.*,cities.name as city_name FROM users LEFT JOIN cities ON cities.id = users.city WHERE users.id = $1 LIMIT 1"
var QueryGetLogin string = "SELECT * FROM login_data WHERE login = $1 LIMIT 1"
var QueryGetCity string = "SELECT * FROM cities WHERE name LIKE $1 LIMIT 1"
var QueryGetToken string = "SELECT * FROM tokens WHERE access_token = $1 AND is_valid=true AND valid_until>Now() LIMIT 1"

var QueryInsertToken string = "INSERT INTO tokens (id, \"user\", access_token, create_date, update_date, valid_until, is_valid) " +
	"VALUES (:id,:user,:access_token, :create_date, :update_date, :valid_until, :is_valid)"
var QueryInvalidateTokens string = "UPDATE tokens SET is_valid=false,update_date=Now() WHERE is_valid=true AND valid_until<=Now()"

var QueryInsertUser string = "INSERT INTO users (id, first_name, second_name, birth_date, create_date, update_date, city, description, sex, is_active) " +
	"VALUES (:id,:first_name,:second_name, :birth_date, :create_date, :update_date, :city, :description, :sex, :is_active)"

var QueryInsertLoginData string = "INSERT INTO login_data (id, login, password, \"user\", create_date, update_date, is_active) " +
	"VALUES (:id,:login,:password, :user, :create_date, :update_date, :is_active)"
