package db

import (
	"crypto/sha256"
	"fmt"
	"highload/goncharov/config"
	"log"
	"time"

	"github.com/google/uuid"
	"github.com/jmoiron/sqlx"
)

var connection *sqlx.DB

func Connect() *sqlx.DB {
	if connection != nil {
		return connection
	}
	var err error

	connection, err = sqlx.Connect("pgx", config.MakeDbConnectionRow(true))
	if err != nil {
		log.Fatalln(err)
		panic(err)
	}
	log.Println("Connected to DB:" + config.MakeDbConnectionRow(false))
	return connection
}

type RegisterInfo struct {
	Login      string
	FirstName  string
	SecondName string
	Birthdate  string
	Biography  *string
	City       string
	Sex        string
	Password   string
}

func IvalidateTokens() error {
	connection := Connect()
	_, err := connection.Exec(QueryInvalidateTokens)
	return err
}

func MakeToken(userLogin *LoginData) (Token, error) {
	connection := Connect()

	hash := sha256.Sum256([]byte(uuid.NewString()))

	token := Token{
		Id:          uuid.New(),
		UserId:      userLogin.UserId,
		AccessToken: fmt.Sprintf("%x", hash),
		IsValid:     true,
		CreateDate:  time.Now().Local(),
		UpdateDate:  time.Now().Local(),
		ValidUntil:  time.Now().Local().Add(time.Hour*1 + time.Minute*0 + time.Second*0),
	}

	_, err := connection.NamedExec(QueryInsertToken, map[string]interface{}{
		"id":           token.Id.String(),
		"user":         token.UserId.String(),
		"access_token": token.AccessToken,
		"is_valid":     token.IsValid,
		"create_date":  token.CreateDate.Format(time.RFC3339),
		"update_date":  token.UpdateDate.Format(time.RFC3339),
		"valid_until":  token.ValidUntil.Format(time.RFC3339),
	})

	return token, err

}
